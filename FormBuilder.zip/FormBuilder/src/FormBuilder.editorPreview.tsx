import { Component, ReactNode, createElement } from "react";
import { FormBuilderPreviewProps } from "../typings/FormBuilderProps";

declare function require(name: string): string;

export class preview extends Component<FormBuilderPreviewProps> {
  render(): ReactNode {
    return <div>FormBuilderPreview</div>;
  }
}

export function getPreviewCss(): string {
  return require("./ui/FormBuilder.scss");
}
