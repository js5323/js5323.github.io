import { Component, ReactNode, createElement, CSSProperties } from "react";
import { observer } from "mobx-react";
import classNames from "classnames";
import Table, { ColumnProps } from "antd/es/table";
import { FormBuilderStore } from "../store";

export interface TreeTableProps {
  store: FormBuilderStore;
  columns: Array<ColumnProps<any>>;
  dataSource?: any[];
  tableHeader?: ReactNode;
  rowSelection?: any;
  className?: string;
  style?: CSSProperties;
}

@observer
class TreeTable extends Component<TreeTableProps> {
  // constructor(props: TreeTableProps) {
  //     super(props);
  // }

  render(): ReactNode {
    const { className, style, columns, dataSource } = this.props;
    return (
      <div className={classNames("asit-treetable-wrapper", className)} style={style} >
        {this.props.tableHeader}
        <Table dataSource={dataSource} columns={columns} rowKey="guid"></Table>
      </div>
    );
  }
}

export default TreeTable;
