import { Component, ReactNode, createElement, CSSProperties } from "react";
import { observer } from "mobx-react";
import classNames from "classnames";
import { FormBuilderStore } from "../store";
import { Input, InputNumber, DatePicker, TimePicker, Checkbox, Radio, Switch, Select, TreeSelect } from 'antd';
import locale from 'antd/es/date-picker/locale/zh_CN';

export interface TreeTableProps {
    store: FormBuilderStore;
    className?: string;
    style?: CSSProperties;
    fields: any[];
    onLeave?: (value: any, field: any) => Promise<void>;
}

@observer
class FormRowContainer extends Component<TreeTableProps> {
    render(): ReactNode {
        const { className, style, fields } = this.props;
        const that = this;

        let content: any[] = [];
        if (fields !== undefined) {
            content = fields.map(function (field) {
                const handleChange = (e: any) => {
                    const value = e.target.value;
                    if (that.props.onLeave) {
                        that.props.onLeave(value, field);
                    }
                }

                switch (field.Types) {
                    // 单行文本
                    case "Textbox":
                        return (
                            <div className={"mx-textbox form-group no-columns mx-name-textbox-" + field.guid}>
                                <label className="control-label" htmlFor={"textBox_" + field.guid}>{field.Title}</label>
                                <Input id={"textBox_" + field.guid} size="large" placeholder={field.Tips} data-guid={field.guid} defaultValue={field.Value} onChange={handleChange} />
                            </div>
                        )

                    // 多行文本
                    case "Textarea":
                        const { TextArea } = Input;
                        return (
                            <div className={"mx-textarea form-group no-columns mx-name-textarea-" + field.guid}>
                                <label className="control-label" htmlFor={"textarea_" + field.guid}>{field.Title}</label>
                                <TextArea id={"textarea_" + field.guid} rows={4} placeholder={field.Tips} data-guid={field.guid} defaultValue={field.Value} onChange={handleChange} />
                            </div>
                        )

                    // 数字
                    case "Number":
                        const numberHandleChange = (value: number | string) => {
                            if (that.props.onLeave) {
                                that.props.onLeave(value, field);
                            }
                        }
                        
                        return (
                            <div className={"mx-number form-group no-columns mx-name-number-" + field.guid}>
                                <label className="control-label" htmlFor={"number_" + field.guid}>{field.Title}</label>
                                <InputNumber id={"number_" + field.guid} size="large" placeholder={field.Tips} style={{ width: '100%' }} data-guid={field.guid} defaultValue={field.Value} onChange={numberHandleChange} onStep={numberHandleChange} />
                            </div>
                        )

                    // 密码
                    case "Password":
                        return (
                            <div className={"mx-password form-group no-columns mx-name-password-" + field.guid}>
                                <label className="control-label" htmlFor={"password_" + field.guid}>{field.Title}</label>
                                <Input.Password id={"password_" + field.guid} size="large" placeholder={field.Tips} data-guid={field.guid} defaultValue={field.Value} onChange={handleChange} />
                            </div>
                        )

                    // 隐藏
                    case "Hidden":
                        return (
                            <div className={"mx-hidden form-group no-columns mx-name-hidden-" + field.guid} style={{ display: 'none' }}>
                                <label className="control-label" htmlFor={"hidden_" + field.guid}>{field.Title}</label>
                                <Input id={"hidden_" + field.guid} size="large" placeholder={field.Tips} data-guid={field.guid} defaultValue={field.Value} />
                            </div>
                        )

                    // 复选框
                    case "Checkbox":
                        const CheckboxGroup = Checkbox.Group;
                        const checkboxOptions: any[] = field.Options.split("\n");
                        const checkboxDefaultValue: string[] = field.Value ? field.Value.split(",") : [];
                        const checkboxHandleChange = (list: any[]) => {
                            const value = list.length <= 0 ? "" : list.join(",");

                            if (that.props.onLeave) {
                                that.props.onLeave(value, field);
                            }
                        }

                        return (
                            <div className={"mx-checkbox form-group no-columns mx-name-checkbox-" + field.guid}>
                                <label className="control-label" htmlFor={"checkbox_" + field.guid}>{field.Title}</label>
                                <CheckboxGroup 
                                    options={checkboxOptions}
                                    defaultValue={checkboxDefaultValue}
                                    onChange={checkboxHandleChange}
                                 />
                            </div>
                        )

                    // 单选按钮
                    case "Radio":
                        const radioOptions: any[] = field.Options.split("\n");

                        return (
                            <div className={"mx-radio form-group no-columns mx-name-radio-" + field.guid}>
                                <label className="control-label" htmlFor={"radio_" + field.guid}>{field.Title}</label>
                                <Radio.Group 
                                    options={radioOptions}
                                    defaultValue={field.Value}
                                    onChange={handleChange}
                                    />
                            </div>
                        )

                    // 开关
                    case "Switches":
                        const defaultChecked = field.Value === "1";
                        const switchHandleChange = (checked: boolean) => {
                            const value = checked ? "1" : "0";
                            
                            if (that.props.onLeave) {
                                that.props.onLeave(value, field);
                            }
                        }

                        return (
                            <div className={"mx-switch form-group no-columns mx-name-switch-" + field.guid}>
                                <label className="control-label" htmlFor={"switch_" + field.guid}>{field.Title}</label>
                                <div>
                                <Switch
                                    defaultChecked={defaultChecked}
                                    onChange={switchHandleChange}
                                    />
                                </div>
                            </div>
                        )

                    // 下拉框
                    case "Select":
                    // 标签
                    case "Tags":
                        const mode = field.Types === "Tags" ? "tags" : undefined;
                        const { Option } = Select;
                        const options: any[] = field.Options.split("\n");
                        const makeOptionItem = function (val: any) {
                            return <Option value={val}>{val}</Option>;
                        };
                        const selectHandleChange = (value: any) => {
                            if (that.props.onLeave) {
                                that.props.onLeave(value, field);
                            }
                        }
                        const defaultValue = field.Value ? field.Value : undefined;

                        field.Tips = field.Tips != "" ? field.Tips : "请选择一项";

                        return (
                            <div className="mx-name-select mx-select form-group no-columns">
                                <label className="control-label">{field.Title}</label>
                                <Select
                                    showSearch
                                    mode={mode}
                                    size="large"
                                    placeholder={field.Tips}
                                    filterOption={(input, option: any) =>
                                        option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                                    }
                                    data-guid={field.guid}
                                    defaultValue={defaultValue}
                                    onChange={selectHandleChange}
                                >
                                    {options.map(makeOptionItem)}
                                </Select>
                            </div>
                        )

                    // 树选择
                    case "TreeSelect":
                        const treeData = [
                            {
                                title: 'Node1',
                                value: '0-0',
                                children: [
                                    {
                                        title: 'Child Node1',
                                        value: '0-0-1',
                                    },
                                    {
                                        title: 'Child Node2',
                                        value: '0-0-2',
                                    },
                                ],
                            },
                            {
                                title: 'Node2',
                                value: '0-1',
                            },
                        ];

                        field.Tips = field.Tips != "" ? field.Tips : "请选择一项";

                        return (
                            <div className="mx-name-textBox2 mx-textbox form-group no-columns">
                                <label className="control-label" htmlFor={"number_" + field.guid}>{field.Title}</label>
                                <TreeSelect
                                    size="large"
                                    style={{ width: '100%' }}
                                    dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
                                    treeData={treeData}
                                    placeholder={field.Tips}
                                    treeDefaultExpandAll
                                />
                            </div>
                        )

                    // 日期
                    case "Date":
                    // 日期+时间
                    case "Datetime":
                        const showTime = field.Types === "Datetime";
                        const format = field.Types === "Datetime" ? "YYYY-MM-DD HH:mm:ss" : "YYYY-MM-DD";
                        const datetimeHandleChange = (value: any, dateString: any) => {
                            console.debug(value);
                            if (that.props.onLeave) {
                                that.props.onLeave(dateString, field);
                            }
                        }

                        return (
                            <div className={"mx-Datetime form-group no-columns mx-name-Datetime-" + field.guid}>
                                <label className="control-label" htmlFor={"Datetime_" + field.guid}>{field.Title}</label>
                                <DatePicker
                                    showTime={showTime}
                                    locale={locale}
                                    style={{ width: '100%' }}
                                    size="large"
                                    format={format}
                                    onChange={datetimeHandleChange}
                                />
                            </div>
                        )

                    // 时间
                    case "Time":
                        const timeFormat = "HH:mm:ss";
                        const timeHandleChange = (value: any, dateString: any) => {
                            console.debug(value);
                            if (that.props.onLeave) {
                                that.props.onLeave(dateString, field);
                            }
                        }

                        return (
                            <div className={"mx-Datetime form-group no-columns mx-name-Datetime-" + field.guid}>
                                <label className="control-label" htmlFor={"Datetime_" + field.guid}>{field.Title}</label>
                                <TimePicker
                                    locale={locale}
                                    style={{ width: '100%' }}
                                    size="large"
                                    format={timeFormat}
                                    onChange={timeHandleChange}
                                />
                            </div>
                        )

                    // 日期范围
                    case "DateRange":
                    // 日期+时间范围
                    case "DatetimeRange":
                        const rangeShowTime = field.Types === "DatetimeRange";
                        const rangeformat = field.Types === "DatetimeRange" ? "YYYY-MM-DD HH:mm:ss" : "YYYY-MM-DD";
                        const datetimeRangeHandleChange = (dates: any, dateStrings: any) => {
                            console.debug(dates);
                            if (that.props.onLeave) {
                                that.props.onLeave(dateStrings.join(","), field);
                            }
                        }

                        return (
                            <div className={"mx-DatetimeRange form-group no-columns mx-name-DatetimeRange-" + field.guid}>
                                <label className="control-label" htmlFor={"DatetimeRange_" + field.guid}>{field.Title}</label>
                                <DatePicker.RangePicker
                                    showTime={rangeShowTime}
                                    locale={locale}
                                    style={{ width: '100%' }}
                                    size="large"
                                    format={rangeformat}
                                    onChange={datetimeRangeHandleChange}
                                />
                            </div>
                        )
                }
            });
        }

        return (
            <div className={classNames("rj-form-builder-wrapper", className)} style={style} >
                {content}
            </div>
        );
    }
}

export default FormRowContainer;
