import { observable, configure, action, computed } from "mobx";
import { ValidationMessage } from "@jeltemx/mendix-react-widget-utils";

export interface TreeRowObject {
    _parent?: string;
    [other: string]: any;
}

configure({ enforceActions: "observed" });

export interface FormBuilderStoreProps {
    attachedReference: string;
    fieldReference: string;
    debug: () => void;
}

export class FormBuilderStore {
    debug: (...args: unknown[]) => void;

    private attachedFieldValueObject: object | null = null;
    @observable attachedReference: string = "";
    @observable fieldReference: string = "";
    @observable isLoading = false;
    @observable contextObject: mendix.lib.MxObject | null = null;
    @observable formFieldList: mendix.lib.MxObject[] = [];
    @observable validationMessages: ValidationMessage[] = [];
    @observable subscriptionHandles: number[] = [];

    constructor({ debug, attachedReference = "", fieldReference = "" }: FormBuilderStoreProps) {
        this.debug = debug;
        this.attachedReference = attachedReference;
        this.fieldReference = fieldReference;
    }

    @computed
    get formFieldDataList(): any[] {
        let attrs: string[] = [];
        let data = this.formFieldList.map(mxObject => {
            let newItem: any = {
                guid: mxObject.getGuid()
            };
            if (!attrs.length) {
                attrs = mxObject.getAttributes();
            }
            attrs.forEach(key => {
                newItem[key] = mxObject.get(key);

                if (key === "Value" && this.attachedFieldValueObject !== null && this.attachedFieldValueObject.hasOwnProperty(newItem["guid"])) {
                    newItem["Value"] = this.attachedFieldValueObject[newItem["guid"]];
                }
            });
            return newItem;
        });
        return data;
    }

    @computed
    get formFields(): any[] {
        return this.formFieldDataList.length <= 0 ? [] : this.formFieldDataList;
    }

    @action
    setContext(obj?: mendix.lib.MxObject): void {
        this.contextObject = obj || null;
    }

    @action
    setAttachedFieldValueObject(attachedFieldValueObject: object | null): void {
        this.attachedFieldValueObject = attachedFieldValueObject;
    }

    @action
    setFormFieldList(mxObjects: mendix.lib.MxObject[] = []): void {
        this.formFieldList = mxObjects;
    }

    @action
    setLoading(isLoading: boolean): void {
        this.isLoading = isLoading;
    }

    @action
    addValidationMessage(message: ValidationMessage): void {
        this.validationMessages.push(message);
    }

    @action
    removeValidationMessage(id: string): void {
        const messages = [...this.validationMessages];
        const found = messages.findIndex(m => m.id === id);
        if (found !== -1) {
            messages.splice(found, 1);
            this.validationMessages = messages;
        }
    }

    @action
    clearSubscriptions(from = ""): void {
        this.debug("store: clearSubscriptions // from: ", from);
        if (this.subscriptionHandles && this.subscriptionHandles.length > 0) {
            this.subscriptionHandles.forEach(window.mx.data.unsubscribe);
            this.subscriptionHandles = [];
        }
    }

    @action
    resetSubscriptions(from = "", handler: () => void): void {
        this.clearSubscriptions(from);
        this.debug("store: resetSubscriptions // from: ", from);

        const { subscribe } = window.mx.data;

        if (this.contextObject && this.contextObject.getGuid) {
            const guid = this.contextObject.getGuid();
            this.subscriptionHandles.push(
                subscribe({
                    callback: () => {
                        this.debug(`store: subcription fired context ${guid}`);
                        this.clearSubscriptions("store context subscription");
                        handler();
                    },
                    guid
                })
            );
        }
    }
}
