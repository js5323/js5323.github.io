import { Component, ReactNode, createElement } from "react";
import { findDOMNode } from "react-dom";
import { observer } from "mobx-react";
import { FormBuilderContainerProps } from "../typings/FormBuilderProps";
import { getObjects, createObject, IAction } from "@jeltemx/mendix-react-widget-utils";
import { ListValue } from 'mendix';
import { FormBuilderStore } from "./store/index";
import FormRowContainer from "./components/FormRowContainer";

import "./ui/FormBuilder.scss";

export interface Action extends IAction {}
export type ActionReturn = null | string | number | boolean | mendix.lib.MxObject | mendix.lib.MxObject[] | void;

export interface FormBuilderProps extends FormBuilderContainerProps {
  mxObject?: mendix.lib.MxObject
}

@observer
export default class FormBuilder extends Component<FormBuilderProps> {
  private widgetId?: string;
  private store: FormBuilderStore;
  private progressId: number = 0;
  private attachedData: object = {};

  private readonly debug = this._debug.bind(this);
  private readonly onLeaveHandle = this.onLeave.bind(this);

  constructor(props: FormBuilderProps) {
    super(props);

    this.store = new FormBuilderStore({
      attachedReference: props.attachedReference,
      fieldReference: props.fieldReference,
      debug: this.debug
    });
  }

  componentWillReceiveProps(nextProps: FormBuilderProps): void {
    if (!this.widgetId) {
      const domNode = findDOMNode(this);
      // @ts-ignore
      this.widgetId = domNode.getAttribute("widgetId") || undefined;
    }

    if (nextProps.contextData.status == "available") {
      this._handleContextData(nextProps.contextData);
    }

    if (nextProps.contextData.status == "available" && nextProps.data.status == "available") {
      this._handleData(nextProps.data);
      this.progressId && mx.ui.hideProgress(this.progressId);
    } else {
      if (this.progressId === 0) {
        this.progressId = mx.ui.showProgress("数据加载中");
      }
    }
  }

  componentDidUpdate(): void {
    if (this.widgetId) {
      const domNode = findDOMNode(this);
      // eslint-disable-next-line @typescript-eslint/ban-ts-ignore
      // @ts-ignore
      domNode.setAttribute("widgetId", this.widgetId);
    }
  }

  render(): ReactNode {
    return (
      <FormRowContainer
        store={this.store}
        className={this.props.class}
        fields={this.store.formFields}
        onLeave={this.onLeaveHandle}
      />
    );
  }

  private _debug(...args: unknown[]): void {
    const id = this.widgetId;
    if (window.logger) {
      window.logger.debug(`${id}:`, ...args);
    }
  }

  private async _handleContextData(objects: ListValue) {
    this.debug("handle data:", objects);

    if (objects.items && objects.items.length) {
      const mxObjects = await getObjects(objects.items.map(({ id }) => id));
      if (mxObjects) {
        this.store.setContext(mxObjects[0]);
      }
    }
  }

  private async _handleData(objects: ListValue) {
    this.debug("handle data:", objects);

    if (objects.items && objects.items.length) {
      const mxObjects = await getObjects(objects.items.map(({ id }) => id));
      if (mxObjects) {
        const attachedFieldValueObject: object | null = await this._getAttachedFieldValueObject(mxObjects);
        this.store.setAttachedFieldValueObject(attachedFieldValueObject);

        this.store.setFormFieldList(mxObjects);
      }
    }
  }

  private async _getAttachedFieldValueObject(mxObjects: mendix.lib.MxObject[] = []): Promise<object | null> {
    if (!this.store.contextObject) return null;
    if (mxObjects.length <= 0) return null;

    const attachedObjectRefs = this.store.contextObject.getReferences("DeviceManagement.Device_DeviceAttached");
    if (attachedObjectRefs.length <= 0) return null;
    
    const attachedMxObjects = await getObjects(attachedObjectRefs);
    if (!attachedMxObjects) return null;

    let attachedFieldValueObject: object = {};
    attachedMxObjects.forEach((mxObject: mendix.lib.MxObject) => {
      const fieldGuid: string = mxObject.get("DeviceManagement.DeviceAttached_DeviceField").toString();
      attachedFieldValueObject[fieldGuid] = mxObject.get("Value");

      this.attachedData[fieldGuid] = mxObject;
    });
    return attachedFieldValueObject;
  }

  private async onLeave(value: any, field: any): Promise<void> {
    if (!this.store.contextObject) {
      return;
    }

    const guid = field.guid;

    if (!this.attachedData.hasOwnProperty(guid)) {
      const attachedObject = await createObject("DeviceManagement.DeviceAttached");
      attachedObject.set("DeviceManagement.DeviceAttached_DeviceField", guid);
      attachedObject.set("Value", value);
      this.attachedData[guid] = attachedObject;

      this.store.contextObject.addReference("DeviceManagement.Device_DeviceAttached", attachedObject.getGuid());
    } else {
      const attachedObject = this.attachedData[guid];
      if (attachedObject) {
        attachedObject.set("Value", value);
      }
    }
    // this.props.selectNodeId.setValue(value);

    // 处理同步更新DataView关联字段
    if (this.props.syncUpdateField) {
      const syncUpdateFields = this.props.syncUpdateField.split(",");
      syncUpdateFields.forEach(syncUpdateFieldItem => {
        if (syncUpdateFieldItem === field.Name && this.store.contextObject) {
          this.store.contextObject.set(syncUpdateFieldItem, value);
        }
      });
    }

    if (this.props.onChangeAction?.canExecute) {
      this.props.onChangeAction.execute();
    }
  }
}
