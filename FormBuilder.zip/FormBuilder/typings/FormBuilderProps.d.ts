/**
 * This file was generated from FormBuilder.xml
 * WARNING: All changes made to this file will be overwritten
 * @author Mendix UI Content Team
 */
import { CSSProperties } from "react";
import { ActionValue, EditableValue, ListValue } from "mendix";

export interface FormBuilderContainerProps {
    name: string;
    class: string;
    style?: CSSProperties;
    tabIndex: number;
    contextData: ListValue;
    data: ListValue;
    selectNodeId: EditableValue<string>;
    syncUpdateField: string;
    attachedReference: string;
    fieldReference: string;
    onChangeAction?: ActionValue;
}

export interface FormBuilderPreviewProps {
    class: string;
    style: string;
    contextData: {} | null;
    data: {} | null;
    selectNodeId: string;
    syncUpdateField: string;
    attachedReference: string;
    fieldReference: string;
    onChangeAction: {} | null;
}
